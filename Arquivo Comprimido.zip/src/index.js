require('babel-core/register')

exports = module.exports = require('./app')
