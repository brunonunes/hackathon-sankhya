import mongoose, {
  Schema
} from 'mongoose'
import mongooseKeywords from 'mongoose-keywords'

const studentSchema = new Schema({
  name: Number,
  email: Number,
  age: Number,
  graduation: String,
  curriculum: String,
  skills: [{
    type: Schema.Types.ObjectId,
    ref: 'Skill'
  }]
}, {
  timestamps: true
})


studentSchema.methods = {
  view(full) {
    const view = {}
    let fields = ['id', 'name', 'email', 'graduation', 'curriculum', 'age']
    if (full) {
      fields = [...fields]
    }

    fields.forEach((field) => {
      view[field] = this[field]
    })

    return view
  }
}

studentSchema.plugin(mongooseKeywords, {
  paths: ['name', 'email']
})

const model = mongoose.model('Student', studentSchema)

export const schema = model.schema
export default model
