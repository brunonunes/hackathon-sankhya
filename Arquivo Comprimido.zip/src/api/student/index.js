import { Router } from 'express'
import { middleware as query } from 'querymen'
import { middleware as body } from 'bodymen'
import { index, show, create, update, destroy } from './controller'
import { schema } from './model'

export Student, { schema } from './model'

const router = new Router()
const { begin, end, days, fee } = schema.tree


router.get('/',
  query(),
  index)

router.get('/:id',
  show)

router.post('/',
  body({ begin, end, days, fee }),
  create)

router.put('/:id',
  body({ begin, end, days, fee }),
  update)

router.delete('/:id',
  destroy)

export default router
