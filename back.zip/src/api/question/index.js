import { Router } from 'express'
import { middleware as query } from 'querymen'
import { middleware as body } from 'bodymen'
import { index, show, create, update, destroy, selectSkill, bySkill, answer, dashboard } from './controller'
import { schema } from './model'

export Question, { schema } from './model'

const router = new Router()
const { title, optionA, optionB, optionC, optionD, optionE, correct, questions } = schema.tree

/**
 * @api {get} /questions/:id Get Question by Id
 * @apiName GetById
 * @apiGroup Questions
 * @apiParam {String} id Question's id.
 * @apiSuccess {Object} question Question's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Question not found.
 * @apiError 401 admin access only.
 */
router.get('/',
  query(),
  index)

router.get('/dashboard',
  query(),
  dashboard)

router.get('/questions',
  query(),
  selectSkill)

router.get('/questions/:id',
  query(),
  bySkill)

router.get('/answer/:id',
  query(),
  answer)

  /**
 * @api {post} /questions Create question
 * @apiName CreateQuestion
 * @apiGroup Questions
 * @apiPermission admin
 * @apiSuccess {Object} question Question's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Question not found.
 * @apiError 401 admin access only.
 */
router.get('/:id',
  show)


/**
 * @api {post} /questions Create question
 * @apiName CreateQuestion
 * @apiGroup Questions
 * @apiPermission admin
 * @apiSuccess {Object} question Question's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Question not found.
 * @apiError 401 admin access only.
 */
router.post('/',
  body({ title, optionA, optionB, optionC, optionD, optionE, correct, questions }),
  create)

    /**
 * @api {put} /questions Update question
 * @apiName UpdateQuestion
 * @apiGroup Questions
 * @apiPermission admin
 * @apiSuccess {Object} question Question's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Question not found.
 * @apiError 401 admin access only.
 */
router.put('/:id',
  body({ title, optionA, optionB, optionC, optionD, optionE, correct, questions }),
  update)

    /**
 * @api {delete} /questions Delete question
 * @apiName DeleteQuestion
 * @apiGroup Questions
 * @apiPermission admin
 * @apiParam {String} question question's id.
 * @apiParam {String} access_token admin access token.
 * @apiParam {String} name Question's name.
 * @apiSuccess {Object} question Question's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Question not found.
 * @apiError 401 admin access only.
 */
router.delete('/:id',
  destroy)

export default router


