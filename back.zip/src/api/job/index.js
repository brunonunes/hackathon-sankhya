import { Router } from 'express'
import { middleware as query } from 'querymen'
import { middleware as body } from 'bodymen'
import { index, indexFb, show, create, update, destroy } from './controller'
import { schema } from './model'

export Job, { schema } from './model'

const router = new Router()
const { name, description, company, jobs } = schema.tree

/**
 * @api {get} /jobs List Jobs
 * @apiName ListJobs
 * @apiGroup Jobs
 * @apiSuccess {Object} JOB Job's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Job not found.
 * @apiError 401 admin access only.
 */
router.get('/',
  query(),
  index)

router.get('/fb',
  query(),
  indexFb)

/**
* @api {get} /jobs/:id Get Job by Id
* @apiName GetById
* @apiGroup Jobs
* @apiParam {String} id Job's id.
* @apiSuccess {Object} JOB Job's data.
* @apiError {Object} 400 Some parameters may contain invalid values.
* @apiError 404 Job not found.
* @apiError 401 admin access only.
*/

router.get('/:id',
  show)

/**
 * @api {post} /jobs Create JOB
 * @apiName CreateJob
 * @apiGroup Jobs
 * @apiPermission admin
 * @apiSuccess {Object} JOB Job's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Job not found.
 * @apiError 401 admin access only.
 */
router.post('/',
  body({ name, description, company, jobs }),
  create)

/**
* @api {put} /jobs Update JOB
* @apiName UpdateJob
* @apiGroup Jobs
* @apiPermission admin
* @apiSuccess {Object} JOB Job's data.
* @apiError {Object} 400 Some parameters may contain invalid values.
* @apiError 404 Job not found.
* @apiError 401 admin access only.
*/
router.put('/:id',
  body({ name, description, company, jobs }),
  update)

/**
* @api {delete} /jobs Delete JOB
* @apiName DeleteJob
* @apiGroup Jobs
* @apiPermission admin
* @apiParam {String} JOB JOB's id.
* @apiParam {String} access_token admin access token.
* @apiParam {String} name Job's name.
* @apiSuccess {Object} JOB Job's data.
* @apiError {Object} 400 Some parameters may contain invalid values.
* @apiError 404 Job not found.
* @apiError 401 admin access only.
*/


router.delete('/:id',
  destroy)

export default router

