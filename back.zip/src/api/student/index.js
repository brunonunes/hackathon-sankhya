import { Router } from 'express'
import { middleware as query } from 'querymen'
import { middleware as body } from 'bodymen'
import { index, show, create, update, destroy } from './controller'
import { schema } from './model'

export Student, { schema } from './model'

const router = new Router()
const { name, email, age, graduation } = schema.tree

/**
 * @api {get} /students List Students
 * @apiName ListStudents
 * @apiGroup Students
 * @apiSuccess {Object} student Student's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Student not found.
 * @apiError 401 admin access only.
 */
router.get('/',
  query(),
  index)

  /**
 * @api {get} /students/:id Get Student by Id
 * @apiName GetById
 * @apiGroup Students
 * @apiParam {String} id Student's id.
 * @apiSuccess {Object} student Student's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Student not found.
 * @apiError 401 admin access only.
 */
router.get('/:id',
  show)

  /**
 * @api {post} /students Create student
 * @apiName CreateStudent
 * @apiGroup Students
 * @apiPermission admin
 * @apiSuccess {Object} student Student's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Student not found.
 * @apiError 401 admin access only.
 */
router.post('/',
  body({ name, email, age, graduation }),
  create)

  /**
 * @api {put} /students Update student
 * @apiName UpdateStudent
 * @apiGroup Students
 * @apiPermission admin
 * @apiSuccess {Object} student Student's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Student not found.
 * @apiError 401 admin access only.
 */
router.put('/:id',
  body({ name, email, age, graduation }),
  update)

  /**
 * @api {delete} /students Delete student
 * @apiName DeleteStudent
 * @apiGroup Students
 * @apiPermission admin
 * @apiParam {String} workstudent student's id.
 * @apiParam {String} access_token admin access token.
 * @apiParam {String} name Student's name.
 * @apiSuccess {Object} student Student's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Student not found.
 * @apiError 401 admin access only.
 */
router.delete('/:id',
  destroy)

export default router
