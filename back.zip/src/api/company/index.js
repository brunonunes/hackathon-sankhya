import { Router } from 'express'
import { middleware as query } from 'querymen'
import { middleware as body } from 'bodymen'
import { index, show, create, update, destroy } from './controller'
import { schema } from './model'

export Company, { schema } from './model'

const router = new Router()
const { name, description, image } = schema.tree

/**
 * @api {get} /companies List Skills
 * @apiName ListSkills
 * @apiGroup Skills
 * @apiSuccess {Object} company Skill's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Skill not found.
 * @apiError 401 admin access only.
 */
router.get('/',
  query(),
  index)


/**
 * @api {get} /companies/:id Get Skill by Id
 * @apiName GetById
 * @apiGroup Skills
 * @apiParam {String} id Skill's id.
 * @apiSuccess {Object} company Skill's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Skill not found.
 * @apiError 401 admin access only.
 */
router.get('/:id',
  show)


/**
 * @api {post} /companies Create company
 * @apiName CreateCompany
 * @apiGroup Companies
 * @apiPermission admin
 * @apiSuccess {Object} company Company's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Company not found.
 * @apiError 401 admin access only.
 */
router.post('/',
  body({ name, description, image }),
  create)

/**
* @api {put} /companies Update company
* @apiName UpdateCompany
* @apiGroup Companies
* @apiPermission admin
* @apiSuccess {Object} company Company's data.
* @apiError {Object} 400 Some parameters may contain invalid values.
* @apiError 404 Company not found.
* @apiError 401 admin access only.
*/
router.put('/:id',
  body({ name, description, image }),
  update)

/**
* @api {delete} /companies Delete company
* @apiName DeleteCompany
* @apiGroup Companies
* @apiPermission admin
* @apiParam {String} company company's id.
* @apiParam {String} access_token admin access token.
* @apiParam {String} name Company's name.
* @apiSuccess {Object} company Company's data.
* @apiError {Object} 400 Some parameters may contain invalid values.
* @apiError 404 Company not found.
* @apiError 401 admin access only.
*/
router.delete('/:id',
  destroy)

export default router
