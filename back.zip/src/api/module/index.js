import { Router } from 'express'
import { middleware as query } from 'querymen'
import { middleware as body } from 'bodymen'
import { index, indexFb, show, create, update, destroy } from './controller'
import { schema } from './model'

export Module, { schema } from './model'

const router = new Router()
const { name, description, image } = schema.tree


/**
 * @api {get} /modules List Modules
 * @apiName ListModules
 * @apiGroup Modules
 * @apiSuccess {Object} module Module's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Module not found.
 * @apiError 401 admin access only.
 */
router.get('/',
  query(),
  index)

router.get('/fb',
  query(),
  indexFb)

/**
* @api {get} /modules/:id Get Module by Id
* @apiName GetById
* @apiGroup Modules
* @apiParam {String} id Module's id.
* @apiSuccess {Object} module Module's data.
* @apiError {Object} 400 Some parameters may contain invalid values.
* @apiError 404 Module not found.
* @apiError 401 admin access only.
*/
router.get('/:id',
  show)


/**
 * @api {post} /modules Create module
 * @apiName CreateModule
 * @apiGroup Modules
 * @apiPermission admin
 * @apiSuccess {Object} module Module's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Module not found.
 * @apiError 401 admin access only.
 */
router.post('/',
  body({ name, description, image }),
  create)

/**
* @api {put} /modules Update module
* @apiName UpdateModule
* @apiGroup Modules
* @apiPermission admin
* @apiSuccess {Object} module Module's data.
* @apiError {Object} 400 Some parameters may contain invalid values.
* @apiError 404 Module not found.
* @apiError 401 admin access only.
*/
router.put('/:id',
  body({ name, description, image }),
  update)

  /**
* @api {delete} /modules Delete module
* @apiName DeleteModule
* @apiGroup Modules
* @apiPermission admin
* @apiParam {String} module module's id.
* @apiParam {String} access_token admin access token.
* @apiParam {String} name Module's name.
* @apiSuccess {Object} module Module's data.
* @apiError {Object} 400 Some parameters may contain invalid values.
* @apiError 404 Module not found.
* @apiError 401 admin access only.
*/

router.delete('/:id',
  destroy)

export default router