import { Router } from 'express'
import { middleware as query } from 'querymen'
import { middleware as body } from 'bodymen'
import { index, indexFb, show, create, update, destroy } from './controller'
import { schema } from './model'

export Skill, { schema } from './model'

const router = new Router()
const { name, description, image } = schema.tree

/**
 * @api {get} /skills List Skills
 * @apiName ListSkills
 * @apiGroup Skills
 * @apiSuccess {Object} skill Skill's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Skill not found.
 * @apiError 401 admin access only.
 */
router.get('/',
  query(),
  index)

router.get('/fb',
  query(),
  indexFb)

/**
 * @api {get} /skills/:id Get Skill by Id
 * @apiName GetById
 * @apiGroup Skills
 * @apiParam {String} id Skill's id.
 * @apiSuccess {Object} skill Skill's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Skill not found.
 * @apiError 401 admin access only.
 */
router.get('/:id',
  show)

/**
 * @api {post} /skills Create skill
 * @apiName CreateSkill
 * @apiGroup Skills
 * @apiPermission admin
 * @apiSuccess {Object} skill Skill's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Skill not found.
 * @apiError 401 admin access only.
 */
router.post('/',
  body({ name, description, image }),
  create)


  /**
 * @api {put} /skills Update skill
 * @apiName UpdateSkill
 * @apiGroup Skills
 * @apiPermission admin
 * @apiSuccess {Object} skill Skill's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Skill not found.
 * @apiError 401 admin access only.
 */
router.put('/:id',
  body({ name, description, image }),
  update)

  /**
 * @api {delete} /skills Delete skill
 * @apiName DeleteSkill
 * @apiGroup Skills
 * @apiPermission admin
 * @apiParam {String} skill skill's id.
 * @apiParam {String} access_token admin access token.
 * @apiParam {String} name Skill's name.
 * @apiSuccess {Object} skill Skill's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Skill not found.
 * @apiError 401 admin access only.
 */
router.delete('/:id',
  destroy)

export default router
