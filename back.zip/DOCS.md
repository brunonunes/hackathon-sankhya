# hackagroup-api v0.0.0



- [Companies](#companies)
	- [Create company](#create-company)
	- [Delete company](#delete-company)
	- [Update company](#update-company)
	
- [Duels](#duels)
	- [List Duels](#list-duels)
	
- [Jobs](#jobs)
	- [Create JOB](#create-job)
	- [Delete JOB](#delete-job)
	- [Get Job by Id](#get-job-by-id)
	- [List Jobs](#list-jobs)
	- [Update JOB](#update-job)
	
- [Modules](#modules)
	- [Create module](#create-module)
	- [Delete module](#delete-module)
	- [Get Module by Id](#get-module-by-id)
	- [List Modules](#list-modules)
	- [Update module](#update-module)
	
- [Questions](#questions)
	- [Create question](#create-question)
	- [Delete question](#delete-question)
	- [Get Question by Id](#get-question-by-id)
	- [Update question](#update-question)
	
- [Skills](#skills)
	- [Create skill](#create-skill)
	- [Delete skill](#delete-skill)
	- [Get Skill by Id](#get-skill-by-id)
	- [List Skills](#list-skills)
	- [Update skill](#update-skill)
	
- [Students](#students)
	- [Create student](#create-student)
	- [Delete student](#delete-student)
	- [Get Student by Id](#get-student-by-id)
	- [List Students](#list-students)
	- [Update student](#update-student)
	


# Companies

## Create company



	POST /companies


## Delete company



	DELETE /companies


### Parameters

| Name    | Type      | Description                          |
|---------|-----------|--------------------------------------|
| company			| String			|  <p>company's id.</p>							|
| access_token			| String			|  <p>admin access token.</p>							|
| name			| String			|  <p>Company's name.</p>							|

## Update company



	PUT /companies


# Duels

## List Duels



	GET /duels


# Jobs

## Create JOB



	POST /jobs


## Delete JOB



	DELETE /jobs


### Parameters

| Name    | Type      | Description                          |
|---------|-----------|--------------------------------------|
| JOB			| String			|  <p>JOB's id.</p>							|
| access_token			| String			|  <p>admin access token.</p>							|
| name			| String			|  <p>Job's name.</p>							|

## Get Job by Id



	GET /jobs/:id


### Parameters

| Name    | Type      | Description                          |
|---------|-----------|--------------------------------------|
| id			| String			|  <p>Job's id.</p>							|

## List Jobs



	GET /jobs


## Update JOB



	PUT /jobs


# Modules

## Create module



	POST /modules


## Delete module



	DELETE /modules


### Parameters

| Name    | Type      | Description                          |
|---------|-----------|--------------------------------------|
| module			| String			|  <p>module's id.</p>							|
| access_token			| String			|  <p>admin access token.</p>							|
| name			| String			|  <p>Module's name.</p>							|

## Get Module by Id



	GET /modules/:id


### Parameters

| Name    | Type      | Description                          |
|---------|-----------|--------------------------------------|
| id			| String			|  <p>Module's id.</p>							|

## List Modules



	GET /modules


## Update module



	PUT /modules


# Questions

## Create question



	POST /questions


## Delete question



	DELETE /questions


### Parameters

| Name    | Type      | Description                          |
|---------|-----------|--------------------------------------|
| question			| String			|  <p>question's id.</p>							|
| access_token			| String			|  <p>admin access token.</p>							|
| name			| String			|  <p>Question's name.</p>							|

## Get Question by Id



	GET /questions/:id


### Parameters

| Name    | Type      | Description                          |
|---------|-----------|--------------------------------------|
| id			| String			|  <p>Question's id.</p>							|

## Update question



	PUT /questions


# Skills

## Create skill



	POST /skills


## Delete skill



	DELETE /skills


### Parameters

| Name    | Type      | Description                          |
|---------|-----------|--------------------------------------|
| skill			| String			|  <p>skill's id.</p>							|
| access_token			| String			|  <p>admin access token.</p>							|
| name			| String			|  <p>Skill's name.</p>							|

## Get Skill by Id



	GET /companies/:id


### Parameters

| Name    | Type      | Description                          |
|---------|-----------|--------------------------------------|
| id			| String			|  <p>Skill's id.</p>							|

## List Skills



	GET /skills


## Update skill



	PUT /skills


# Students

## Create student



	POST /students


## Delete student



	DELETE /students


### Parameters

| Name    | Type      | Description                          |
|---------|-----------|--------------------------------------|
| workstudent			| String			|  <p>student's id.</p>							|
| access_token			| String			|  <p>admin access token.</p>							|
| name			| String			|  <p>Student's name.</p>							|

## Get Student by Id



	GET /students/:id


### Parameters

| Name    | Type      | Description                          |
|---------|-----------|--------------------------------------|
| id			| String			|  <p>Student's id.</p>							|

## List Students



	GET /students


## Update student



	PUT /students



