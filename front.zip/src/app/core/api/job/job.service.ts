import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError, finalize } from 'rxjs/operators';
import { environment as env } from '@env/environment';
import { LoaderService } from '../../loader/loader.service'
import { LocalStorageService } from '../../local-storage/local-storage.service';

@Injectable()
export class JobService {
  headers
  constructor(private httpClient: HttpClient, private localStorageService: LocalStorageService, private loaderService: LoaderService) {
    this.headers = new HttpHeaders().set('Content-Type', 'application/json')
  }

  create(job: any) {
    this.loaderService.show()
    return this.httpClient
      .post(`${env.apiURL}/jobs`, job)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }

  update(job: any) {
    this.loaderService.show()
    return this.httpClient
      .put(`${env.apiURL}/jobs/${job.id}`, job)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }

  list(query: string, page: number, limit: number, sort: string, loading: boolean) {
    if (loading)
      this.loaderService.show()
    return this.httpClient
      .get(`${env.apiURL}/jobs?q=${query}&page=${page}&limit=${limit}&sort=${sort}`, { headers: this.headers })
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => {
          if (loading)
            this.loaderService.hide()
        })
      )
  }

  delete(jobId) {
    this.loaderService.show()
    return this.httpClient
      .delete(`${env.apiURL}/jobs/${jobId}`)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }
}
