import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError, finalize } from 'rxjs/operators';
import { environment as env } from '@env/environment';
import { LoaderService } from '../../loader/loader.service'
import { LocalStorageService } from '../../local-storage/local-storage.service';

@Injectable()
export class DashboardService {
  headers
  constructor(private httpClient: HttpClient, private localStorageService: LocalStorageService, private loaderService: LoaderService) {
    this.headers = new HttpHeaders().set('Content-Type', 'application/json')
  }

  list(query: string, page: number, limit: number, sort: string, loading: boolean) {
    if (loading)
      this.loaderService.show()
    return this.httpClient
      .get(`${env.apiURL}/dashboard?q=${query}&page=${page}&limit=${limit}&sort=${sort}`, { headers: this.headers })
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => {
          if (loading)
            this.loaderService.hide()
        })
      )
  }

  listMessages(dahsboardId) {
    this.loaderService.show()
    return this.httpClient
      .post(`${env.apiBotURL}/botkit/history`, { dahsboard: dahsboardId }, { headers: this.headers })
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }

  sendNegotiation(dahsboardId) {
    this.loaderService.show()
    return this.httpClient
      .post(`${env.apiURL}/dashboard/${dahsboardId}/notify`, null)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }
}
