import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError, finalize } from 'rxjs/operators';
import { environment as env } from '@env/environment';
import { LoaderService } from '../../loader/loader.service'
import { LocalStorageService } from '../../local-storage/local-storage.service';

@Injectable()
export class SkillService {
  headers
  constructor(private httpClient: HttpClient, private localStorageService: LocalStorageService, private loaderService: LoaderService) {
    this.headers = new HttpHeaders().set('Content-Type', 'application/json')
  }

  create(skill: any) {
    this.loaderService.show()
    return this.httpClient
      .post(`${env.apiURL}/skills`, skill)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }

  update(skill: any) {
    this.loaderService.show()
    return this.httpClient
      .put(`${env.apiURL}/skills/${skill.id}`, skill)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }

  list(query: string, page: number, limit: number, sort: string, loading: boolean) {
    if (loading)
      this.loaderService.show()
    return this.httpClient
      .get(`${env.apiURL}/skills?q=${query}&page=${page}&limit=${limit}&sort=${sort}`, { headers: this.headers })
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => {
          if (loading)
            this.loaderService.hide()
        })
      )
  }

  delete(skillId) {
    this.loaderService.show()
    return this.httpClient
      .delete(`${env.apiURL}/skills/${skillId}`)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }
}
