import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError, finalize } from 'rxjs/operators';
import { environment as env } from '@env/environment';
import { LoaderService } from '../../loader/loader.service'
import { LocalStorageService } from '../../local-storage/local-storage.service';

@Injectable()
export class QuestionaryService {
  headers
  constructor(private httpClient: HttpClient, private localStorageService: LocalStorageService, private loaderService: LoaderService) {
    this.headers = new HttpHeaders().set('Content-Type', 'application/json')
  }

  create(questionary: any) {
    this.loaderService.show()
    return this.httpClient
      .post(`${env.apiURL}/questions`, questionary)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }

  update(questionary: any) {
    this.loaderService.show()
    return this.httpClient
      .put(`${env.apiURL}/questions/${questionary.id}`, questionary)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }

  list(query: string, page: number, limit: number, sort: string, loading: boolean) {
    if (loading)
      this.loaderService.show()
    return this.httpClient
      .get(`${env.apiURL}/questions?q=${query}&page=${page}&limit=${limit}&sort=${sort}`, { headers: this.headers })
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => {
          if (loading)
            this.loaderService.hide()
        })
      )
  }

  delete(questionaryId) {
    this.loaderService.show()
    return this.httpClient
      .delete(`${env.apiURL}/questions/${questionaryId}`)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }
}
