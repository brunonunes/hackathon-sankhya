import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError, finalize } from 'rxjs/operators';
import { environment as env } from '@env/environment';
import { LoaderService } from '../../loader/loader.service'
import { LocalStorageService } from '../../local-storage/local-storage.service';

@Injectable()
export class ModuleService {
  headers
  constructor(private httpClient: HttpClient, private localStorageService: LocalStorageService, private loaderService: LoaderService) {
    this.headers = new HttpHeaders().set('Content-Type', 'application/json')
  }

  create(module: any) {
    this.loaderService.show()
    return this.httpClient
      .post(`${env.apiURL}/modules`, module)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }

  update(module: any) {
    this.loaderService.show()
    return this.httpClient
      .put(`${env.apiURL}/modules/${module.id}`, module)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }

  list(query: string, page: number, limit: number, sort: string, loading: boolean) {
    if (loading)
      this.loaderService.show()
    return this.httpClient
      .get(`${env.apiURL}/modules?q=${query}&page=${page}&limit=${limit}&sort=${sort}`, { headers: this.headers })
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => {
          if (loading)
            this.loaderService.hide()
        })
      )
  }

  delete(moduleId) {
    this.loaderService.show()
    return this.httpClient
      .delete(`${env.apiURL}/modules/${moduleId}`)
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }
}
