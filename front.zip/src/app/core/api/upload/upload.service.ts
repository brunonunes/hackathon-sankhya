import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError, finalize } from 'rxjs/operators';
import { environment as env } from '@env/environment';
import { LoaderService } from '../../loader/loader.service'
import { LocalStorageService } from '../../local-storage/local-storage.service';

@Injectable()
export class UploadService {
  headers
  constructor(private httpClient: HttpClient, private localStorageService: LocalStorageService, private loaderService: LoaderService) {
    this.headers = new HttpHeaders().set('Content-Type', 'application/json')

  }

  create(upload) {
    this.loaderService.show()
    return this.httpClient
      .post(`${env.apiURL}/upload`, upload, { headers: this.headers })
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }

  list() {
    this.loaderService.show()
    return this.httpClient
      .get(`${env.apiURL}/upload`, { headers: this.headers })
      .pipe(
        map((response: any) => {
          return response
        }),
        finalize(() => this.loaderService.hide())
      )
  }
}
