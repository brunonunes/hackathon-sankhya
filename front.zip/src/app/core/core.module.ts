import { NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { MetaReducer, StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { storeFreeze } from 'ngrx-store-freeze';

import { environment } from '@env/environment';

import { debug } from './meta-reducers/debug.reducer';
import { initStateFromLocalStorage } from './meta-reducers/init-state-from-local-storage.reducer';
import { LocalStorageService } from './local-storage/local-storage.service';
import { UploadService } from './api/upload/upload.service';
import { UserService } from './api/user/user.service';
import { DashboardService } from './api/dashboard/dashboard.service';
import { BillingService } from './api/billing/billing.service';
import { SkillService } from './api/skill/skill.service';
import { ModuleService } from './api/module/module.service';
import { QuestionaryService } from './api/questionary/questionary.service';
import { NotificationService } from './api/notification/notification.service';
import { CompanyService } from './api/company/company.service';
import { JobService } from './api/job/job.service';
import { ProcessService } from './api/process/process.service';
import { IntentService } from './api/intent/intent.service';
import { authReducer } from './auth/auth.reducer';
import { AuthEffects } from './auth/auth.effects';
import { AuthGuardService } from './auth/auth-guard.service';
import { LoaderComponent } from './loader/loader.component'
import { LoaderService } from './loader/loader.service'

export const metaReducers: MetaReducer<any>[] = [initStateFromLocalStorage];

if (!environment.production) {
  metaReducers.unshift(debug, storeFreeze);
}

@NgModule({
  imports: [
    // angular
    CommonModule,
    HttpClientModule,



    // ngrx
    StoreModule.forRoot(
      {
        auth: authReducer
      },
      { metaReducers }
    ),
    EffectsModule.forRoot([AuthEffects])

  ],
  exports: [
    LoaderComponent
  ],
  declarations: [
    LoaderComponent
  ],
  providers: [LocalStorageService, AuthGuardService, DashboardService, ModuleService, QuestionaryService, JobService, NotificationService, LoaderService, CompanyService, SkillService, BillingService, UserService, UploadService, ProcessService, IntentService]
})
export class CoreModule {
  constructor(
    @Optional()
    @SkipSelf()
    parentModule: CoreModule
  ) {
    if (parentModule) {
      throw new Error('CoreModule is already loaded. Import only in AppModule');
    }
  }
}
