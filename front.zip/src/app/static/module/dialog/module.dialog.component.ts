import { Component, ViewChild, OnInit, Inject } from '@angular/core'
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material'
import { MatDatepickerInputEvent } from '@angular/material/datepicker'
import { FormControl } from '@angular/forms'
import { Observable } from 'rxjs'
import { map, startWith } from 'rxjs/operators'
import { ModuleService } from '@app/core'
import { MatSnackBar } from '@angular/material/snack-bar'

@Component({
  selector: 'module-dialog',
  templateUrl: 'module.dialog.component.html',
  styleUrls: ['./module.dialog.component.scss']
})
export class ModuleDialog {
  myControl: FormControl = new FormControl()

  constructor(
    private moduleService: ModuleService,
    public snackBar: MatSnackBar,
    public dialogRef: MatDialogRef<ModuleDialog>,
    @Inject(MAT_DIALOG_DATA) public module: any) {

  }

  close() {
    this.dialogRef.close()
  }

  newModule() {
    this.moduleService.create(this.module).subscribe(
      data => this.dialogRef.close(),
      err => {
        console.log("dei err: ", err)
        this.showNotification(err.error.message || 'Confira os dados e tente novamente.', 'Ok')
      }
    )
  }

  updateModule() {
    this.moduleService.update(this.module).subscribe(
      data => this.dialogRef.close(),
      err => {
        console.log("chegou,", err)
      }
    )
  }

  action() {
    if (this.module.isCreating) {
      this.newModule()
    } else {
      this.updateModule()
    }
  }

  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    })
  }
}