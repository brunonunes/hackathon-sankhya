import { Component, ViewChild, OnInit, Inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ANIMATE_ON_ROUTE_ENTER } from '@app/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { ModuleService } from '@app/core';
import { ProcessService } from '@app/core';
import { ModuleDialog } from './dialog/module.dialog.component'
import { ConfirmationDialog } from '../dialog/confirmation.dialog.component';

@Component({
  selector: 'anms-module',
  templateUrl: './module.component.html',
  styleUrls: ['./module.component.scss']
})
export class ModuleComponent implements OnInit {
  animateOnRouteEnter = ANIMATE_ON_ROUTE_ENTER;
  constructor(public moduleService: ModuleService, public dialog: MatDialog, public snackBar: MatSnackBar) { }
  modules: Module[] = [];
  isSearch: Boolean = false

  query = ''
  page = 1
  sort = 'begin'
  length = 0;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25];

  ngOnInit() {
    this.listModules('', true)
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim()
    this.query = filterValue.toLowerCase()
    this.listModules(this.query, false)
  }

  openSearch(search) {
    this.query = ''
    this.listModules(this.query, false)
    this.isSearch = search
  }

  changePage(event) {
    this.pageSize = event.pageSize
    this.page = event.pageIndex + 1
    this.listModules(this.query, true)
  }

  create() {
    this.openDialog({ isCreating: true })
  }

  edit(module) {
    module.isCreating = false
    this.openDialog(Object.assign({}, module))
  }

  openDialog(module) {
    const dialogRef = this.dialog.open(ModuleDialog, {
      width: '600px',
      data: module,
    });
    dialogRef.afterClosed().subscribe(result => {
      this.listModules('', false)
    });
  }

  delete(module) {
    const deleteDialog = this.dialog.open(ConfirmationDialog, {
      data: { name: module.name, type: "Módulo" }
    })
    deleteDialog.afterClosed().subscribe(result => {
      if (result.remove) {
        this.moduleService.delete(module.id).subscribe(
          data => {
            this.showNotification("Module removido com sucesso.", "Ok")
            this.listModules('', false)
          },
          err => this.showNotification("Não foi possível remover a module.", "Ok")
        )
      }
    })
  }

  listModules(query: string, loading: boolean) {
    this.moduleService.list(query, this.page, this.pageSize, this.sort, loading).subscribe(
      data => {
        this.length = data.count
        this.modules = data.rows
      },
      err => this.showNotification(err.error.message, 'ok')
    )
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['image', 'name', 'description','createdAt', 'options'];
  dataSource = new MatTableDataSource(this.modules);



  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    });
  }


}

export interface Module {
  begin: number;
  end: string;
  days: string;
  fee: string;
}


