import { Component, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'confirmation.dialog.component',
  templateUrl: 'confirmation.dialog.component.html',
  styleUrls: ['./confirmation.dialog.component.scss']
})
export class ConfirmationDialog {

  constructor(
    public dialogRef: MatDialogRef<ConfirmationDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  cancel(remove): void {
    this.dialogRef.close({
      remove
    })
  }
}