import { NgModule } from '@angular/core';

import { SharedModule } from '@app/shared';

import { StaticRoutingModule } from './static-routing.module';
import { AboutComponent } from './about/about.component';
import { FeaturesComponent } from './features/features.component';
import { HomeComponent } from './home/home.component';
import { UsersComponent } from './users/users.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SkillComponent } from './skills/skills.component';
import { ModuleComponent } from './module/module.component';
import { QuestionaryComponent } from './questionary/questionary.component';
import { NotificationComponent } from './notification/notification.component';
import { CompanyComponent } from './company/company.component';
import { JobComponent } from './jobs/jobs.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { SkillDialog } from './skills/dialog/skills.dialog.component';
import { ModuleDialog } from './module/dialog/module.dialog.component';
import { UsersDialog } from './users/dialog/users.dialog.component';
import { QuestionaryDialog } from './questionary/dialog/questionary.dialog.component';
import { NotificationDialog } from './notification/dialog/notification.dialog.component';
import { CompanyDialog } from './company/dialog/company.dialog.component';
import { JobDialog } from './jobs/dialog/jobs.dialog.component';
import { ConfirmationDialog } from './dialog/confirmation.dialog.component';
import { Ng2GoogleChartsModule } from 'ng2-google-charts';


@NgModule({
  imports: [Ng2GoogleChartsModule, SharedModule, StaticRoutingModule, FormsModule, ReactiveFormsModule, TextMaskModule],
  entryComponents: [ModuleDialog, UsersDialog, SkillDialog, QuestionaryDialog, NotificationDialog, JobDialog, CompanyDialog, ConfirmationDialog],
  declarations: [AboutComponent, UsersDialog, DashboardComponent, ModuleDialog, FeaturesComponent, ModuleComponent, QuestionaryDialog, QuestionaryComponent, NotificationDialog, NotificationComponent, JobDialog, JobComponent, CompanyDialog, CompanyComponent, ConfirmationDialog, SkillDialog, SkillComponent, HomeComponent, UsersComponent]
})
export class StaticModule { }
