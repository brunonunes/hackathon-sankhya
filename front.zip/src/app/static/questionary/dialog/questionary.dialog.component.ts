import { Component, ViewChild, OnInit, Inject } from '@angular/core'
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material'
import { MatDatepickerInputEvent } from '@angular/material/datepicker'
import { FormControl } from '@angular/forms'
import { Observable } from 'rxjs'
import { map, startWith } from 'rxjs/operators'
import { QuestionaryService } from '@app/core'
import { SkillService } from '@app/core'
import { MatSnackBar } from '@angular/material/snack-bar'

@Component({
  selector: 'questionary-dialog',
  templateUrl: 'questionary.dialog.component.html',
  styleUrls: ['./questionary.dialog.component.scss']
})
export class QuestionaryDialog {
  myControl: FormControl = new FormControl()
  skills: any

  constructor(
    private questionaryService: QuestionaryService,
    public skillService: SkillService,
    public snackBar: MatSnackBar,
    public dialogRef: MatDialogRef<QuestionaryDialog>,
    @Inject(MAT_DIALOG_DATA) public questionary: any) {
      this.getSkills()
  }

  close() {
    this.dialogRef.close()
  }

  processSkills() {
    this.questionary.skills = []
    this.skills.forEach(skill => {
      if(skill.isChecked){
        this.questionary.skills.push(skill.id)
      }
    })
  }

  getSkills() {
    this.skillService.list('', 1, 100, "name", false).subscribe(
      data => {
        this.skills = data.rows
      },
      err => this.showNotification(err.error.message, 'ok')
    )
  }

  newQuestionary() {

    this.questionaryService.create(this.questionary).subscribe(
      data => this.dialogRef.close(),
      err => {
        console.log("dei err: ", err)
        this.showNotification(err.error.message || 'Confira os dados e tente novamente.', 'Ok')
      }
    )
  }

  updateQuestionary() {
    this.questionaryService.update(this.questionary).subscribe(
      data => this.dialogRef.close(),
      err => {
        console.log("chegou,", err)
      }
    )
  }

  action() {
    this.processSkills()
    if (this.questionary.isCreating) {
      this.newQuestionary()
    } else {
      this.updateQuestionary()
    }
  }

  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    })
  }
}