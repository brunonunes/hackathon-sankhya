import { Component, ViewChild, OnInit, Inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ANIMATE_ON_ROUTE_ENTER } from '@app/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { QuestionaryService } from '@app/core';
import { ProcessService } from '@app/core';
import { QuestionaryDialog } from './dialog/questionary.dialog.component'
import { ConfirmationDialog } from '../dialog/confirmation.dialog.component';

@Component({
  selector: 'anms-questionary',
  templateUrl: './questionary.component.html',
  styleUrls: ['./questionary.component.scss']
})
export class QuestionaryComponent implements OnInit {
  animateOnRouteEnter = ANIMATE_ON_ROUTE_ENTER;
  constructor(public questionaryService: QuestionaryService, public dialog: MatDialog, public snackBar: MatSnackBar) { }
  questionarys: Questionary[] = [];
  isSearch: Boolean = false

  query = ''
  page = 1
  sort = 'begin'
  length = 0;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25];

  ngOnInit() {
    this.listQuestionarys('', true)
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim()
    this.query = filterValue.toLowerCase()
    this.listQuestionarys(this.query, false)
  }

  openSearch(search) {
    this.query = ''
    this.listQuestionarys(this.query, false)
    this.isSearch = search
  }

  changePage(event) {
    this.pageSize = event.pageSize
    this.page = event.pageIndex + 1
    this.listQuestionarys(this.query, true)
  }

  create() {
    this.openDialog({ isCreating: true })
  }

  edit(questionary) {
    questionary.isCreating = false
    this.openDialog(Object.assign({}, questionary))
  }

  openDialog(questionary) {
    const dialogRef = this.dialog.open(QuestionaryDialog, {
      width: '600px',
      data: questionary,
    });
    dialogRef.afterClosed().subscribe(result => {
      this.listQuestionarys('', false)
    });
  }

  delete(questionary) {
    const deleteDialog = this.dialog.open(ConfirmationDialog, {
      data: { name: questionary.name, type: "Questionary" }
    })
    deleteDialog.afterClosed().subscribe(result => {
      if (result.remove) {
        this.questionaryService.delete(questionary.id).subscribe(
          data => {
            this.showNotification("Questionário removido com sucesso.", "Ok")
            this.listQuestionarys('', false)
          },
          err => this.showNotification("Não foi possível remover o questionário.", "Ok")
        )
      }
    })
  }

  listQuestionarys(query: string, loading: boolean) {
    this.questionaryService.list(query, this.page, this.pageSize, this.sort, loading).subscribe(
      data => {
        this.length = data.count
        this.questionarys = data.rows
      },
      err => this.showNotification(err.error.message, 'ok')
    )
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['title', 'alternatives', 'skills', 'createdAt', 'options'];
  dataSource = new MatTableDataSource(this.questionarys);



  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    });
  }


}

export interface Questionary {
  begin: number;
  end: string;
  days: string;
  fee: string;
}


