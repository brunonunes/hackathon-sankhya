import { Component, ViewChild, OnInit, Inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ANIMATE_ON_ROUTE_ENTER } from '@app/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { DashboardService } from '@app/core';
import { ProcessService } from '@app/core';

@Component({
  selector: 'anms-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  animateOnRouteEnter = ANIMATE_ON_ROUTE_ENTER;
  constructor(public dashboardService: DashboardService, public dialog: MatDialog, public snackBar: MatSnackBar) { }
  dashboards: Dashboard[] = [];
  isSearch: Boolean = false

  pieChartData =  {
    chartType: 'PieChart',
    dataTable: [
      ['Questão', 'Acertos', 'Erros'],
      ['Work',     11, 2],
      ['Eat',      2, 2],
      ['Commute',  2, 2],
      ['Watch TV', 2, 2],
      ['Sleep',    7, 2]
    ],
    options: {'title': 'Tasks', pieHole: 0.4, legend: 'none',},
  };

  query = ''
  page = 1
  sort = 'name'
  length = 0;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25];

  ngOnInit() {
    this.listDashboard('', true)
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim()
    this.query = filterValue.toLowerCase()
    this.listDashboard(this.query, false)
  }

  openSearch(search) {
    this.query = ''
    this.listDashboard(this.query, false)
    this.isSearch = search
  }

  changePage(event) {
    this.pageSize = event.pageSize
    this.page = event.pageIndex + 1
    this.listDashboard(this.query, true)
  }

  listMessages(dashboard) {
    this.dashboardService.listMessages(dashboard.id).subscribe(
      data => {
        console.log('chegou aqui: ', data)
      },
      err => {
        this.showNotification(err.error.message, 'ok')
      }
    )
  }

  sendNegotiation(dashboard) {
    this.dashboardService.sendNegotiation(dashboard.id).subscribe(
      data => {
        this.showNotification('Proposta enviada com sucesso!', 'ok')
      },
      err => {
        this.showNotification(err.error.message, 'ok')
      }
    )
  }

  capitalize(s) {
    return s.toLowerCase().replace(/\b./g, function (a) { return a.toUpperCase(); });
  }

 
  listDashboard(query: string, loading: boolean) {
    this.dashboardService.list(query, this.page, this.pageSize, this.sort, loading).subscribe(
      data => {
        this.length = data.count
        this.dashboards = data.rows
        this.dashboards.forEach(dashboard => {
          dashboard.name = this.capitalize(dashboard.name)
        })
      },
      err => {
        this.showNotification(err.error.message, 'ok')
      }
    )
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['name', 'email', 'age', 'graduation', 'skills', 'createdAt', 'options'];
  dataSource = new MatTableDataSource(this.dashboards);

  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    });
  }


}

export interface Dashboard {
  name: string;
  email: string;
  cpf: string;
  picutre: string;
  phone: string;
  phone2: string;
  contract: string;
  birthdate: Date;
  address: string;
  createdAt: Date;
}


