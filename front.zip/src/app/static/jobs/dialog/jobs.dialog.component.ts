import { Component, ViewChild, OnInit, Inject } from '@angular/core'
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material'
import { MatDatepickerInputEvent } from '@angular/material/datepicker'
import { FormControl } from '@angular/forms'
import { Observable } from 'rxjs'
import { map, startWith } from 'rxjs/operators'
import { JobService } from '@app/core'
import { MatSnackBar } from '@angular/material/snack-bar'
import { SkillService } from '@app/core';
import { CompanyService } from '@app/core';

@Component({
  selector: 'jobs-dialog',
  templateUrl: 'jobs.dialog.component.html',
  styleUrls: ['./jobs.dialog.component.scss']
})
export class JobDialog {
  myControl: FormControl = new FormControl()
  skills: any
  companies: any

  constructor(
    private jobService: JobService,
    public snackBar: MatSnackBar,
    public dialogRef: MatDialogRef<JobDialog>,
    public skillService: SkillService,
    public companyService: CompanyService,
    @Inject(MAT_DIALOG_DATA) public job: any) {
    this.getSkills()
    this.getCompanies()
  }

  getCompanies() {
    this.companyService.list('', 1, 100, "name", false).subscribe(
      data => {
        this.companies = data.rows
      },
      err => this.showNotification(err.error.message, 'ok')
    )
  }

  getSkills() {
    this.skillService.list('', 1, 100, "name", false).subscribe(
      data => {
        this.skills = data.rows
      },
      err => this.showNotification(err.error.message, 'ok')
    )
  }

  close() {
    this.dialogRef.close()
  }

  newJob() {
    this.processSkills()
    this.jobService.create(this.job).subscribe(
      data => this.dialogRef.close(),
      err => {
        this.showNotification(err.error.message || 'Confira os dados e tente novamente.', 'Ok')
      }
    )
  }

  processSkills() {
    this.job.skills = []
    this.skills.forEach(skill => {
      if(skill.isChecked){
        this.job.skills.push(skill.id)
      }
    })
  }

  updateJob() {
    this.processSkills()
    this.jobService.update(this.job).subscribe(
      data => this.dialogRef.close(),
      err => {
        console.log("chegou,", err)
      }
    )
  }

  action() {
    if (this.job.isCreating) {
      this.newJob()
    } else {
      this.updateJob()
    }
  }

  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    })
  }
}