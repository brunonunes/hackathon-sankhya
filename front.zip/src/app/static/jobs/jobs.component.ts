import { Component, ViewChild, OnInit, Inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ANIMATE_ON_ROUTE_ENTER } from '@app/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { JobService } from '@app/core';
import { ProcessService } from '@app/core';
import { JobDialog } from './dialog/jobs.dialog.component'
import { ConfirmationDialog } from '../dialog/confirmation.dialog.component';

@Component({
  selector: 'anms-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.scss']
})
export class JobComponent implements OnInit {
  animateOnRouteEnter = ANIMATE_ON_ROUTE_ENTER;
  constructor(public jobService: JobService, public dialog: MatDialog, public snackBar: MatSnackBar) { }
  jobs: Job[] = [];
  isSearch: Boolean = false

  query = ''
  page = 1
  sort = 'begin'
  length = 0;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25];

  ngOnInit() {
    this.listCompanies('', true)
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim()
    this.query = filterValue.toLowerCase()
    this.listCompanies(this.query, false)
  }

  openSearch(search) {
    this.query = ''
    this.listCompanies(this.query, false)
    this.isSearch = search
  }

  changePage(event) {
    this.pageSize = event.pageSize
    this.page = event.pageIndex + 1
    this.listCompanies(this.query, true)
  }

  create() {
    this.openDialog({ isCreating: true })
  }

  edit(job) {
    job.isCreating = false
    this.openDialog(Object.assign({}, job))
  }

  openDialog(job) {
    const dialogRef = this.dialog.open(JobDialog, {
      width: '600px',
      data: job,
    });
    dialogRef.afterClosed().subscribe(result => {
      this.listCompanies('', false)
    });
  }

  delete(job) {
    const deleteDialog = this.dialog.open(ConfirmationDialog, {
      data: { name: job.name, type: "Vaga" }
    })
    deleteDialog.afterClosed().subscribe(result => {
      if (result.remove) {
        this.jobService.delete(job.id).subscribe(
          data => {
            this.showNotification("Vaga removida com sucesso.", "Ok")
            this.listCompanies('', false)
          },
          err => this.showNotification("Não foi possível remover esta vaga.", "Ok")
        )
      }
    })
  }

  listCompanies(query: string, loading: boolean) {
    this.jobService.list(query, this.page, this.pageSize, this.sort, loading).subscribe(
      data => {
        this.length = data.count
        this.jobs = data.rows
      },
      err => this.showNotification(err.error.message, 'ok')
    )
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['image', 'name', 'description', 'skills', 'options'];
  dataSource = new MatTableDataSource(this.jobs);



  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    });
  }


}

export interface Job {
  begin: number;
  end: string;
  days: string;
  fee: string;
}


