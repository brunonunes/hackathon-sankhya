import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ANIMATE_ON_ROUTE_ENTER } from '@app/core';
import { Store } from '@ngrx/store';
import {
  ActionAuthLogin
} from '@app/core';


@Component({
  selector: 'anms-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  animateOnRouteEnter = ANIMATE_ON_ROUTE_ENTER;
  currentScreen = 'dashboard'
  constructor(private store: Store<any>) { 
    this.store.dispatch(new ActionAuthLogin())
  }

  ngOnInit() { }

  changeScreen(screen){
    this.currentScreen = screen
  }

  navigationSideMenu = [
    { link: 'dashboard', label: 'Dashboard', icon: 'show_chart' },
    { link: 'users', label: 'Talentos', icon: 'group' },
    { link: 'questionary', label: 'Perguntas', icon: 'format_list_numbered' },
    { link: 'skills', label: 'Skills', icon: 'flash_on' },
    { link: 'module', label: 'Módulos', icon: 'description' },
    { link: 'company', label: 'Empresas', icon: 'store_mall_directory' },
    { link: 'jobs', label: 'Vagas', icon: 'how_to_reg' },
    { link: 'notification', label: 'Notificações', icon: 'notifications' },
    { link: 'logout', label: 'Sair', icon: 'person' }
  ];

}
