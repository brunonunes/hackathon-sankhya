import { Component, ViewChild, OnInit, Inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ANIMATE_ON_ROUTE_ENTER } from '@app/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { SkillService } from '@app/core';
import { ProcessService } from '@app/core';
import { SkillDialog } from './dialog/skills.dialog.component'
import { ConfirmationDialog } from '../dialog/confirmation.dialog.component';

@Component({
  selector: 'anms-skills',
  templateUrl: './skills.component.html',
  styleUrls: ['./skills.component.scss']
})
export class SkillComponent implements OnInit {
  animateOnRouteEnter = ANIMATE_ON_ROUTE_ENTER;
  constructor(public skillService: SkillService, public dialog: MatDialog, public snackBar: MatSnackBar) { }
  skills: Skill[] = [];
  isSearch: Boolean = false

  query = ''
  page = 1
  sort = 'begin'
  length = 0;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25];

  ngOnInit() {
    this.listSkills('', true)
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim()
    this.query = filterValue.toLowerCase()
    this.listSkills(this.query, false)
  }

  openSearch(search) {
    this.query = ''
    this.listSkills(this.query, false)
    this.isSearch = search
  }

  changePage(event) {
    this.pageSize = event.pageSize
    this.page = event.pageIndex + 1
    this.listSkills(this.query, true)
  }

  create() {
    this.openDialog({ isCreating: true })
  }

  edit(skill) {
    skill.isCreating = false
    this.openDialog(Object.assign({}, skill))
  }

  openDialog(skill) {
    const dialogRef = this.dialog.open(SkillDialog, {
      width: '600px',
      data: skill,
    });
    dialogRef.afterClosed().subscribe(result => {
      this.listSkills('', false)
    });
  }

  delete(skill) {
    const deleteDialog = this.dialog.open(ConfirmationDialog, {
      data: { name: skill.name, type: "Skill" }
    })
    deleteDialog.afterClosed().subscribe(result => {
      if (result.remove) {
        this.skillService.delete(skill.id).subscribe(
          data => {
            this.showNotification("Skill removido com sucesso.", "Ok")
            this.listSkills('', false)
          },
          err => this.showNotification("Não foi possível remover a skill.", "Ok")
        )
      }
    })
  }

  listSkills(query: string, loading: boolean) {
    this.skillService.list(query, this.page, this.pageSize, this.sort, loading).subscribe(
      data => {
        this.length = data.count
        this.skills = data.rows
      },
      err => this.showNotification(err.error.message, 'ok')
    )
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['image', 'name', 'description', 'options'];
  dataSource = new MatTableDataSource(this.skills);



  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    });
  }


}

export interface Skill {
  begin: number;
  end: string;
  days: string;
  fee: string;
}


