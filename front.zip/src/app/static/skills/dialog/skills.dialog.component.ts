import { Component, ViewChild, OnInit, Inject } from '@angular/core'
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material'
import { MatDatepickerInputEvent } from '@angular/material/datepicker'
import { FormControl } from '@angular/forms'
import { Observable } from 'rxjs'
import { map, startWith } from 'rxjs/operators'
import { SkillService } from '@app/core'
import { MatSnackBar } from '@angular/material/snack-bar'

@Component({
  selector: 'skills-dialog',
  templateUrl: 'skills.dialog.component.html',
  styleUrls: ['./skills.dialog.component.scss']
})
export class SkillDialog {
  myControl: FormControl = new FormControl()

  constructor(
    private skillService: SkillService,
    public snackBar: MatSnackBar,
    public dialogRef: MatDialogRef<SkillDialog>,
    @Inject(MAT_DIALOG_DATA) public skill: any) {

  }

  close() {
    this.dialogRef.close()
  }

  newSkill() {
    this.skillService.create(this.skill).subscribe(
      data => this.dialogRef.close(),
      err => {
        console.log("dei err: ", err)
        this.showNotification(err.error.message || 'Confira os dados e tente novamente.', 'Ok')
      }
    )
  }

  updateSkill() {
    this.skillService.update(this.skill).subscribe(
      data => this.dialogRef.close(),
      err => {
        console.log("chegou,", err)
      }
    )
  }

  action() {
    if (this.skill.isCreating) {
      this.newSkill()
    } else {
      this.updateSkill()
    }
  }

  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    })
  }
}