import { Component, ViewChild, OnInit, Inject } from '@angular/core'
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material'
import { MatDatepickerInputEvent } from '@angular/material/datepicker'
import { FormControl } from '@angular/forms'
import { Observable } from 'rxjs'
import { map, startWith } from 'rxjs/operators'
import { CompanyService } from '@app/core'
import { MatSnackBar } from '@angular/material/snack-bar'

@Component({
  selector: 'company-dialog',
  templateUrl: 'company.dialog.component.html',
  styleUrls: ['./company.dialog.component.scss']
})
export class CompanyDialog {
  myControl: FormControl = new FormControl()

  constructor(
    private companyService: CompanyService,
    public snackBar: MatSnackBar,
    public dialogRef: MatDialogRef<CompanyDialog>,
    @Inject(MAT_DIALOG_DATA) public company: any) {

  }

  close() {
    this.dialogRef.close()
  }

  newCompany() {
    this.companyService.create(this.company).subscribe(
      data => this.dialogRef.close(),
      err => {
        console.log("dei err: ", err)
        this.showNotification(err.error.message || 'Confira os dados e tente novamente.', 'Ok')
      }
    )
  }

  updateCompany() {
    this.companyService.update(this.company).subscribe(
      data => this.dialogRef.close(),
      err => {
        console.log("chegou,", err)
      }
    )
  }

  action() {
    if (this.company.isCreating) {
      this.newCompany()
    } else {
      this.updateCompany()
    }
  }

  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    })
  }
}