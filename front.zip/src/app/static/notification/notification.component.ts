import { Component, ViewChild, OnInit, Inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ANIMATE_ON_ROUTE_ENTER } from '@app/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { NotificationService } from '@app/core';
import { ProcessService } from '@app/core';
import { NotificationDialog } from './dialog/notification.dialog.component'
import { ConfirmationDialog } from '../dialog/confirmation.dialog.component';

@Component({
  selector: 'anms-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})
export class NotificationComponent implements OnInit {
  animateOnRouteEnter = ANIMATE_ON_ROUTE_ENTER;
  constructor(public notificationService: NotificationService, public dialog: MatDialog, public snackBar: MatSnackBar) { }
  notifications: Notification[] = [];
  isSearch: Boolean = false

  query = ''
  page = 1
  sort = 'begin'
  length = 0;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25];

  ngOnInit() {
    this.listNotifications('', true)
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim()
    this.query = filterValue.toLowerCase()
    this.listNotifications(this.query, false)
  }

  openSearch(search) {
    this.query = ''
    this.listNotifications(this.query, false)
    this.isSearch = search
  }

  changePage(event) {
    this.pageSize = event.pageSize
    this.page = event.pageIndex + 1
    this.listNotifications(this.query, true)
  }

  create() {
    this.openDialog({ isCreating: true })
  }

  edit(notification) {
    notification.isCreating = false
    this.openDialog(Object.assign({}, notification))
  }

  openDialog(notification) {
    const dialogRef = this.dialog.open(NotificationDialog, {
      width: '600px',
      data: notification,
    });
    dialogRef.afterClosed().subscribe(result => {
      this.listNotifications('', false)
    });
  }

  delete(notification) {
    const deleteDialog = this.dialog.open(ConfirmationDialog, {
      data: { name: notification.name, type: "Notification" }
    })
    deleteDialog.afterClosed().subscribe(result => {
      if (result.remove) {
        this.notificationService.delete(notification.id).subscribe(
          data => {
            this.showNotification("Notification removido com sucesso.", "Ok")
            this.listNotifications('', false)
          },
          err => this.showNotification("Não foi possível remover a notification.", "Ok")
        )
      }
    })
  }

  listNotifications(query: string, loading: boolean) {
    this.notificationService.list(query, this.page, this.pageSize, this.sort, loading).subscribe(
      data => {
        this.length = data.count
        this.notifications = data.rows
      },
      err => this.showNotification(err.error.message, 'ok')
    )
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['message', 'createdAt'];
  dataSource = new MatTableDataSource(this.notifications);



  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    });
  }


}

export interface Notification {
  begin: number;
  end: string;
  days: string;
  fee: string;
}


