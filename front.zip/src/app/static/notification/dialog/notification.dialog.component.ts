import { Component, ViewChild, OnInit, Inject } from '@angular/core'
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material'
import { MatDatepickerInputEvent } from '@angular/material/datepicker'
import { FormControl } from '@angular/forms'
import { Observable } from 'rxjs'
import { map, startWith } from 'rxjs/operators'
import { NotificationService } from '@app/core'
import { MatSnackBar } from '@angular/material/snack-bar'

@Component({
  selector: 'notification-dialog',
  templateUrl: 'notification.dialog.component.html',
  styleUrls: ['./notification.dialog.component.scss']
})
export class NotificationDialog {
  myControl: FormControl = new FormControl()

  constructor(
    private notificationService: NotificationService,
    public snackBar: MatSnackBar,
    public dialogRef: MatDialogRef<NotificationDialog>,
    @Inject(MAT_DIALOG_DATA) public notification: any) {

  }

  close() {
    this.dialogRef.close()
  }

  newNotification() {
    this.notificationService.create(this.notification).subscribe(
      data => this.dialogRef.close(),
      err => {
        console.log("dei err: ", err)
        this.showNotification(err.error.message || 'Confira os dados e tente novamente.', 'Ok')
      }
    )
  }

  updateNotification() {
    this.notificationService.update(this.notification).subscribe(
      data => this.dialogRef.close(),
      err => {
        console.log("chegou,", err)
      }
    )
  }

  action() {
    if (this.notification.isCreating) {
      this.newNotification()
    } else {
      this.updateNotification()
    }
  }

  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    })
  }
}