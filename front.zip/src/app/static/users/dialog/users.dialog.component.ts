import { Component, ViewChild, OnInit, Inject } from '@angular/core'
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material'
import { MatDatepickerInputEvent } from '@angular/material/datepicker'
import { FormControl } from '@angular/forms'
import { Observable } from 'rxjs'
import { map, startWith } from 'rxjs/operators'
import { UserService } from '@app/core'
import { MatSnackBar } from '@angular/material/snack-bar'

@Component({
  selector: 'users-dialog',
  templateUrl: 'users.dialog.component.html',
  styleUrls: ['./users.dialog.component.scss']
})
export class UsersDialog {
  myControl: FormControl = new FormControl()

  constructor(
    private userService: UserService,
    public snackBar: MatSnackBar,
    public dialogRef: MatDialogRef<UsersDialog>,
    @Inject(MAT_DIALOG_DATA) public user: any) {
      console.log("chegamos: ", user)
  }

  close() {
    this.dialogRef.close()
  }


  action() {
    this.dialogRef.close()
  }

  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    })
  }
}