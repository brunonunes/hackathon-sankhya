import { Component, ViewChild, OnInit, Inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ANIMATE_ON_ROUTE_ENTER } from '@app/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { UserService } from '@app/core';
import { ProcessService } from '@app/core';
import { UsersDialog } from './dialog/users.dialog.component'

@Component({
  selector: 'anms-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  animateOnRouteEnter = ANIMATE_ON_ROUTE_ENTER;
  constructor(public userService: UserService, public dialog: MatDialog, public snackBar: MatSnackBar) { }
  users: User[] = [];
  isSearch: Boolean = false

  query = ''
  page = 1
  sort = 'name'
  length = 0;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25];

  ngOnInit() {
    this.listUsers('', true)
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim()
    this.query = filterValue.toLowerCase()
    this.listUsers(this.query, false)
  }

  openSearch(search) {
    this.query = ''
    this.listUsers(this.query, false)
    this.isSearch = search
  }

  changePage(event) {
    this.pageSize = event.pageSize
    this.page = event.pageIndex + 1
    this.listUsers(this.query, true)
  }

  openDialog(historic) {
    // let dialogRef = this.dialog.open(HistoricDialog, {
    //   width: '600px',
    //   height: '600px',
    //   data: historic,
    // });
    // dialogRef.afterClosed().subscribe(result => {
    //   this.listUsers()
    // });
  }

  listMessages(user) {
    this.userService.listMessages(user.id).subscribe(
      data => {
        console.log('chegou aqui: ', data)
      },
      err => {
        this.showNotification(err.error.message, 'ok')
      }
    )
  }

  sendNegotiation(user) {
    this.userService.sendNegotiation(user.id).subscribe(
      data => {
        this.showNotification('Proposta enviada com sucesso!', 'ok')
      },
      err => {
        this.showNotification(err.error.message, 'ok')
      }
    )
  }

  capitalize(s) {
    return s.toLowerCase().replace(/\b./g, function (a) { return a.toUpperCase(); });
  }

  openTimeline(user) {
    const newUser = Object.assign({}, user)
    console.log("chegou aqyui> ", newUser)
    const dialogRef = this.dialog.open(UsersDialog, {
      width: '600px',
      data: newUser,
    });
    dialogRef.afterClosed().subscribe(result => {

    });
  }

  listUsers(query: string, loading: boolean) {
    this.userService.list(query, this.page, this.pageSize, this.sort, loading).subscribe(
      data => {
        this.length = data.count
        this.users = data.rows
        this.users.forEach(user => {
          user.name = this.capitalize(user.name)
        })
      },
      err => {
        this.showNotification(err.error.message, 'ok')
      }
    )
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['name', 'email', 'age', 'graduation', 'skills', 'createdAt', 'options'];
  dataSource = new MatTableDataSource(this.users);



  private showNotification(message: string, action?: string) {
    return this.snackBar.open(message, action, {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'end'
    });
  }


}

export interface User {
  name: string;
  email: string;
  cpf: string;
  picutre: string;
  phone: string;
  phone2: string;
  contract: string;
  birthdate: Date;
  address: string;
  createdAt: Date;
}


